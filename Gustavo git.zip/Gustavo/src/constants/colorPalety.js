export const colorPrimay = "#318CCA"
export const colorSegundary = "#1A5A8A"